<?php
include 'dbcon.php';
$search = $_GET['query'] ?? '';
$searchTerm = "%$search%";

$stmt = $conn->prepare("
    SELECT * FROM students 
    WHERE fullName LIKE ? 
       OR studentID LIKE ? 
       OR course LIKE ? 
       OR yearLevel LIKE ? 
       OR enrollmentYear LIKE ? 
       OR CONCAT(enrollmentYear, '-', LPAD(studentID, 3, '0')) LIKE ?
");

$stmt->bind_param("ssssss", $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm);
$stmt->execute();
$result = $stmt->get_result();


if ($result->num_rows > 0) {
    while ($student = $result->fetch_assoc()) {
      
        $paddedID = str_pad($student['studentID'], 3, '0', STR_PAD_LEFT);
        $displayID = $student['enrollmentYear'] . '-' . $paddedID;

        echo "<tr>
                <td>{$displayID}</td>
                <td>{$student['fullName']}</td>
                <td>{$student['course']}</td>
                <td>{$student['yearLevel']}</td>
                <td>
                    <a href='deletestudent.php?id={$student['studentID']}' class='btn btn-danger'>Delete</a>
                    <a href='editstudent.php?id={$student['studentID']}' class='btn btn-info'>Update</a>
                </td>
            </tr>";
    }
} else {
    echo "<tr><td colspan='5' class='text-center'>No results found.</td></tr>";
}
?>
