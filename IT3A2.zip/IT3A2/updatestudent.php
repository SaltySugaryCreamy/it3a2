<?php
include 'dbcon.php';
$studentID = $_POST['studentID'];
$fullName = $_POST['fullName'];
$course = $_POST['course'];
$yearLevel =$_POST['yearLevel'];


class updateStudent{

		private $conn;
		private $studentID;
		private $fullName;
		private $course;
		private $yearLevel;


		public function __construct($conn,$studentID,$fullName,$course,$yearLevel){
			$this->conn = $conn;
			$this->fullName =$fullName;
			$this->course = $course;
			$this->yearLevel = $yearLevel;
			$this->studentID = $studentID;
		}

		public function updateStudentInfo(){
			$sql = "UPDATE students set fullName ='$this->fullName', course = '$this->course', yearLevel = '$this->yearLevel' where studentID = '$this->studentID'";
			$result = $this->conn->query($sql);
			return $result;
		}
}

$updateInfo = new updateStudent( $conn,$studentID, $fullName, $course, $yearLevel);
$updateInfo->updateStudentInfo();
header('location:index.php');
?>