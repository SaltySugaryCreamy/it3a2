<?php include('dbcon.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Student List</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
        }
        .search-input {
            max-width: 300px;
        }
        .top-bar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>

<div class="container mt-5">
    <div class="top-bar">
        <input type="text" id="search" class="form-control search-input" placeholder="Search...">
        <a href="add.php" class="btn btn-primary">Add Student</a>
    </div>

    <div class="table-responsive">
       <table class="table" border="1" cellspacing="0" cellpadding="8">
            <thead class="table-dark">
                <tr>
                    <th>Student ID</th>
                    <th>Full Name</th>
                    <th>Course</th>
                    <th>Year Level</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody id="studentTable">
                <?php
                class selectStudentData {
                    private $conn;
                    public function __construct($conn) {
                        $this->conn = $conn;
                        if ($this->conn->connect_error) {
                            die("Connection failed: " . $this->conn->connect_error);
                        }
                    }

                    public function getStudent() {
                        $sql = "SELECT * FROM students";
                        $result = $this->conn->query($sql);
                        $students = [];

                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                $students[] = $row;
                            }
                        }

                        return $students;
                    }
                }

                $studentData = new selectStudentData($conn);
                $students = $studentData->getStudent();
            
if (empty($students)) {
    echo "<tr><td colspan='5' class='text-center'>No student data is found.</td></tr>";
} else {
    foreach ($students as $student) {
        $paddedID = str_pad($student['studentID'], 3, '0', STR_PAD_LEFT);
        $displayID = $student['enrollmentYear'] . '-' . $paddedID;

        echo "<tr>
                <td>{$displayID}</td>
                <td>{$student['fullName']}</td>
                <td>{$student['course']}</td>
                <td>{$student['yearLevel']}</td>
                <td>
                    <a href='deletestudent.php?id={$student['studentID']}' class='btn btn-danger'>Delete</a>
                    <a href='editstudent.php?id={$student['studentID']}' class='btn btn-info'>Update</a>
                </td>
            </tr>";
    }
}


        ?>
            </tbody>
        </table>
    </div>
</div>


<script src="css/bootstrap.min.js"></script>


<script>
document.getElementById('search').addEventListener('input', function () {
    const query = this.value;

    const xhr = new XMLHttpRequest();
    xhr.open("GET", "search-handler.php?query=" + encodeURIComponent(query), true);
    xhr.onload = function () {
        if (xhr.status === 200) {
            document.getElementById('studentTable').innerHTML = xhr.responseText;
        }
    };
    xhr.send();
});
</script>

</body>
</html>
