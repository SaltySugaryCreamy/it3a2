<?php 
include('dbcon.php');

$id = $_GET['id'];

class selectStudentData {
    private $conn;
    private $studentID;
    public function __construct($conn, $studentID) {
        $this->conn = $conn;
        $this->sID = $studentID;

        if ($this->conn->connect_error) {
            die("Connection failed: " . $this->conn->connect_error);
        }
    }

    public function getStudent() {
        $sql = "SELECT * FROM students WHERE studentID = $this->sID";
        $result = $this->conn->query($sql);
        $students = [];

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $students[] = $row;
            }
        }

        return $students;
    }
}

$studentData = new selectStudentData($conn, $id);
$students = $studentData->getStudent(); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Student</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>
        .form-container {
            max-width: 600px;
            margin: 60px auto;
            padding: 30px;
            background: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        h4 {
            margin-bottom: 25px;
        }
    </style>
</head>
<body>

<div class="container">
    <div class="form-container">
        <h4 class="text-center">Update Student Info</h4>
        <form action="updatestudent.php" method="POST">
            <?php foreach ($students as $student): ?>
                <input type="hidden" name="studentID" value="<?= $student['studentID']; ?>" />

                <div class="mb-3">
                    <label for="fullName" class="form-label">Full Name:</label>
                    <input type="text" name="fullName" class="form-control" value="<?= $student['fullName']; ?>" required />
                </div>

                <div class="mb-3">
                    <label for="course" class="form-label">Course:</label>
                    <select name="course" class="form-select" required>
                        <option value="BSIT" <?= ($student['course'] == 'BSIT') ? 'selected' : ''; ?>>BSIT</option>
                        <option value="BScPE" <?= ($student['course'] == 'BScPE') ? 'selected' : ''; ?>>BScPE</option>
                        <option value="BSCE" <?= ($student['course'] == 'BSCE') ? 'selected' : ''; ?>>BSCE</option>
                        <option value="BSHM" <?= ($student['course'] == 'BSHM') ? 'selected' : ''; ?>>BSHM</option>
                        <option value="BSTM" <?= ($student['course'] == 'BSTM') ? 'selected' : ''; ?>>BSTM</option>
                        <option value="BSBA" <?= ($student['course'] == 'BSBA') ? 'selected' : ''; ?>>BSBA</option>
                        <option value="BSArch" <?= ($student['course'] == 'BSArch') ? 'selected' : ''; ?>>BSArch</option>
                    </select>
                </div>

                <div class="mb-4">
                    <label for="yearLevel" class="form-label">Year Level:</label>
                    <select name="yearLevel" class="form-select" required>
                        <option value="1" <?= ($student['yearLevel'] == '1') ? 'selected' : ''; ?>>1st Year</option>
                        <option value="2" <?= ($student['yearLevel'] == '2') ? 'selected' : ''; ?>>2nd Year</option>
                        <option value="3" <?= ($student['yearLevel'] == '3') ? 'selected' : ''; ?>>3rd Year</option>
                        <option value="4" <?= ($student['yearLevel'] == '4') ? 'selected' : ''; ?>>4th Year</option>
                        <option value="5" <?= ($student['yearLevel'] == '5') ? 'selected' : ''; ?>>5th Year</option>
                    </select>
                </div>
            <?php endforeach; ?>

            <div class="d-flex justify-content-between">
                <a href="index.php" class="btn btn-secondary">Cancel</a>
                <button type="submit" class="btn btn-success">Update</button>
            </div>
        </form>
    </div>
</div>

<script src="css/bootstrap.min.js"></script>

</body>
</html>
