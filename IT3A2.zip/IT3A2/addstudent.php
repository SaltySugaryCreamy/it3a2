<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Student</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">

    
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <style>
        body {
            background-color: #f8f9fa;
        }

        .form-container {
            max-width: 550px;
            margin: 80px auto;
            padding: 50px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        .form-title {
            margin-bottom: 20px;
            text-align: center;
            font-weight: bold;
            color: #dc3545; 
        }

        .btn-info {
            float: right;
            margin-bottom: 20px;
        }

        @media (max-width: 576px) {
            .btn-info {
                float: none;
                width: 100%;
                margin-bottom: 10px;
            }
        }
    </style>
</head>
<body>

<div class="container">
    <div class="form-container">
        <h4 class="form-title">Add New Student</h4>

        <a href="index.php" class="btn btn-info">View List</a>
        <div class="clearfix mb-3"></div>

        <form method="post" action="addstudentprocess.php">
            <div class="mb-3">
                <input type="text" class="form-control" id="fullName" name="fullName" required placeholder="Full Name">
            </div>

            <div class="mb-3">
                <select class="form-select" id="course" name="course" required>
                    <option value="" disabled selected>Course</option>
                    <option value="BSIT">BSIT</option>
                    <option value="BScPE">BScPE</option>
                    <option value="BSCE">BSCE</option>
                    <option value="BSHM">BSHM</option>
                    <option value="BSTM">BSTM</option>
                    <option value="BSBA">BSBA</option>
                    <option value="BSArch">BSArch</option>
                </select>
            </div>

            <div class="mb-4">
                <select class="form-select" name="yearLevel" required>
                    <option value="" disabled selected>Year Level</option>
                    <option value="1">1st Year</option>
                    <option value="2">2nd Year</option>
                    <option value="3">3rd Year</option>
                    <option value="4">4th Year</option>
                    <option value="5">5th Year</option>
                </select>
            </div>

            <div class="d-grid">
                <button type="submit" class="btn btn-danger">Submit</button>
            </div>
        </form>
    </div>
</div>

<script src="css/bootstrap.min.js"></script>

</body>
</html>
