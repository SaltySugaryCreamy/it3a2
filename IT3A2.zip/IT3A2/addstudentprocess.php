<?php

include('dbcon.php');

$fullName = $_POST['fullName'];
$course = $_POST['course'];
$yearLevel = $_POST['yearLevel'];


	class studentManager{
		private $fullName;
		private $course;
		private $yearLevel;
		private $conn;

		public function __construct($fullName,$course,$yearLevel,$conn){
			$this->fullName =$fullName;
			$this->course =$course;
			$this->yearLevel =$yearLevel;
			$this->conn =$conn;
		}

		public function studentManager(){
			$sql = "INSERT into students(fullName,course,yearLevel) values('$this->fullName','$this->course','$this->yearLevel')";
			return	$result = $this->conn ->query($sql);
		}
	}

$studentManager = new studentManager( $fullName, $course, $yearLevel, $conn);
$studentManager ->studentManager();
header( 'location:index.php');
?>