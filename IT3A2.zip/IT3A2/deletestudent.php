<?php
include 'dbcon.php';

	$id = $_GET['id'];

 class deleteStudent{
 	private $studentID;
 	private $conn;

 	public function __construct($studentID,$conn){
 		$this->conn = $conn;
 		$this->sID = $studentID;


 	}

 	public function delStudent(){
	$sql = "DELETE from students where studentID=$this->sID";
	$result = $this->conn ->query($sql);		
	return $result;
 	}
 }
$studentDel = new deleteStudent( $id, $conn);
$studentDel->delStudent();
	header( 'location:index.php');	
 ?>