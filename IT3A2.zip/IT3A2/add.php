<!DOCTYPE html>
<html>
<head>
    <title>Add Student</title>
   
<link href="css/bootstrap.min.css" rel="stylesheet">

<script src="css/bootstrap.min.js"></script>
</head>
<center>
<body>
    <div class="container">
       
                <br><br><br><br><br>
                
             <table class="table" border="1" cellspacing="0" cellpadding="8" style="max-width: 30px;">
						<?php include 'addstudent.php'; ?> 
						</div>
					</div>
				</div>


</center>
</form>
            </div>
            <div class="col-2"></div>
        </div>
    </div>
</body>
</html>