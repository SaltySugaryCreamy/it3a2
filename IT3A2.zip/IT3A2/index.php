<!DOCTYPE html>
<html>
<head>
    <title>Student Information</title>
   
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-2"></div>
            <div class="col-8">
                <br><br><br><br><br>
                <h2 class="text-danger">Student Information</h2>
                <hr>
                <?php include('studenttable.php'); ?>
            </div>
            <div class="col-2"></div>
        </div>
    </div>
</body>
</html>
